//Define structure of info regarding space
//Contains all the data and data types regarding space

//Define status
export enum SpaceStatus {
    PUBLIC = 'PUBLIC',
    PRIVATE = 'PRIVATE'
}